Assets folder
